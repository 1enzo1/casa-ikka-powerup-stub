# Casa Ikka – Trello Connector (Stub)

Este repositório serve apenas como **página estática** para preencher o campo
**URL de conector Iframe** no cadastro de Power-Up/Integração do Trello.

## Publicação no GitHub Pages
1. Habilite o GitHub Pages em **Settings → Pages**.
2. Selecione **Deploy from a branch**, branch `main`, pasta `/ (root)`.
3. A URL pública ficará em: `https://SEU_USUARIO.github.io/NOME_DO_REPO/`.

## Arquivos
- `index.html` – página principal (stub)
- `privacy.html` – privacidade
- `support.html` – suporte
- `200.html` – fallback para hosts estáticos

> Não há JS ativo, cookies ou coleta de dados.
